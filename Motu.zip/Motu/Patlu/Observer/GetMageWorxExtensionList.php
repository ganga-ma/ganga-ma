<?php
/**
 * Copyright ©  MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace Motu\Patlu\Observer;

use Magento\Framework\Event\ObserverInterface;

class GetMageWorxExtensionList implements ObserverInterface
{
    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $backendSession;

    /**
     * @var \Motu\Patlu\Helper\Data
     */
    protected $helper;

    /**
     * GetMageWorxOffers constructor.
     *
     * @param \Motu\Patlu\Helper\Data $helper
     * @param \Magento\Backend\Model\Auth\Session $backendSession
     */
    public function __construct(
        \Motu\Patlu\Helper\Data $helper,
        \Magento\Backend\Model\Auth\Session $backendSession
    ) {
        $this->helper         = $helper;
        $this->backendSession = $backendSession;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->backendSession->isLoggedIn() && $this->helper->isExtensionInfoAutoloadEnabled()) {
            $this->helper->checkExtensionListUpdate();
        }
    }
}