var config = {
    map: {
        '*': {
            'mw-review-modal': 'Motu_Patlu/js/mw-review-modal'
        }
    }
};